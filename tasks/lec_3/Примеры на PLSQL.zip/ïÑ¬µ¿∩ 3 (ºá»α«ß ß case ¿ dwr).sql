create or replace   PROCEDURE getBlockingService(dwr OUT sys_refcursor,
                               ID  IN NUMBER) IS
  BEGIN
    OPEN dwr FOR
      Select fbs.id_blockings,
             fbs.id_master_inst as ID,
             fbs.id_master_type as ID_SERVICE_TYPE,
             (Select case fs_in.b_add_service
                       when 0 then
                        '������ - '
                       when 1 then
                        '���. ������ - '
                     end || fs_in.v_name
                from FW_SERVICE fs_in
               where fs_in.b_deleted = 0
                 and fs_in.id_service = (Select fss_in.id_service
                                           from FW_SERVICES fss_in
                                          where fss_in.id_service_inst = fbs.id_master_inst
                                            and fss_in.dt_start < CURRENT_TIMESTAMP
                                            and CURRENT_TIMESTAMP <= fss_in.dt_stop
                                            and fss_in.b_deleted = 0)) V_SERVICE_NAME,
             (select fb_in.v_name
                from FW_BLOCKING fb_in
               where fb_in.b_deleted = 0
                 and fb_in.id_blocking = fbs.id_blocking) as V_BLOCKING,
             (select fbr.v_name
                from Fw_Blocking_Reason fbr
               where fbr.b_deleted = 0
                 and fbr.id_blocking_reason = fbs.id_blocking_reason) as V_BLOCKING_REASON,
             fbs.dt_start as DT_START,
             fbs.dt_stop as DT_STOP,
             nvl((Select t.ID_DEL
                   From (Select (CURRENT_TIMESTAMP) as DT_EVENT, 1 as ID_DEL
                           from dual) t
                  where fbs.dt_start > T.DT_EVENT), 0) B_DEL,
             fbs.ID_BLOCKING,
             fbs.ID_BLOCKING_REASON,
             --case fbs.b_deleted when 0 then '����������' when 1 then '�������' end B_DELETED
             case
                when fbs.b_deleted = 0 and fbs.dt_stop > sysdate then
                 '����������'
                when fbs.b_deleted = 1 then
                 '�������'
                when fbs.b_deleted = 0 and fbs.dt_stop <= sysdate then
                 '�������'
              end B_DELETED
        from FW_BLOCKINGS fbs
       where fbs.id_master_type in (4, 5)
         and (fbs.id_master_inst in
             (Select fs_in.id_service_inst
                 from FW_SERVICES fs_in
                where fs_in.b_deleted = 0
                  and fs_in.b_add_service = 1
                  and fs_in.id_parent_inst = ID) or fbs.id_master_inst = ID)
       order by b_deleted ASC, DT_START DESC;

  END;
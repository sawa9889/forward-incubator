SELECT s.v_name,
       s.b_add_service,
       CASE s.b_add_service
         WHEN 0 THEN
          '��������'
         ELSE
          '��������������'
       END
  FROM fw_service s;

SELECT s.v_name,
       s.b_add_service,
       CASE
         WHEN s.b_add_service = 0 THEN
          '��������'
         ELSE
          '��������������'
       END
  FROM fw_service s;
  

/* == ����� ��������� == */
  P_BASE_EXCHANGE.saveServices(pID_SERVICE_INST    => dID_SERVICE_INST,
                               pDT_START           => pDATE_CUR,
                               pID_SERVICE         => i.id_srv,
                               pID_PRODUCT_INST    => pID_PRODUCT_INST,
                               pV_STATUS           => case
                                                        when i.v_ext_ident = 'NET' then
                                                         'A'
                                                        else
                                                         'W'
                                                      end,
                               pID_DEPENDENCY_INST => null);

/*====================*/

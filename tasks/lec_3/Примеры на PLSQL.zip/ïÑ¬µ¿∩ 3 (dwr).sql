CREATE OR REPLACE PROCEDURE getServiceByName(dwr OUT sys_refcursor , pV_NAME IN VARCHAR) IS
  BEGIN
    OPEN dwr FOR
      SELECT * FROM fw_service s WHERE UPPER(s.v_name)  LIKE  UPPER('%'||pV_NAME||'%');
      
  END;
/

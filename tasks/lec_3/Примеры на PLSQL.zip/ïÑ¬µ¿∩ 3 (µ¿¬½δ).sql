FUNCTION get_pass(pLogin IN VARCHAR2) RETURN VARCHAR2 IS

l_password VARCHAR2(15);
  
BEGIN
  FOR i in 1 .. 8 LOOP  
    l_password := l_password || substr('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ',
                                       ceil(DBMS_RANDOM.value(0,
                                                              length('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ'))),
                                       1);
  
  end loop;
  RETURN l_password;
END;

/*===============================================================*/

FUNCTION get_pass(pLogin IN VARCHAR2) RETURN VARCHAR2 IS

l_password VARCHAR2(15);
  
BEGIN
  WHILE LENGTH(l_password) < 8 LOOP   
    l_password := l_password || substr('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ',
                                       ceil(DBMS_RANDOM.value(0,
                                                              length('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ'))),
                                       1);
  
  end loop;
  RETURN l_password;
END;

/*===============================================================*/

FUNCTION get_pass(pLogin IN VARCHAR2) RETURN VARCHAR2 IS

l_password VARCHAR2(15);
  
BEGIN
  LOOP   
  	EXIT WHEN LENGTH(l_password) > 8
    l_password := l_password || substr('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ',
                                       ceil(DBMS_RANDOM.value(0,
                                                              length('23456789abcdefghjkmnpqrstuvwxyzABCDEFGHJKNPQRSTUVWXYZ'))),
                                       1);
  
  end loop;
  RETURN l_password;
END;


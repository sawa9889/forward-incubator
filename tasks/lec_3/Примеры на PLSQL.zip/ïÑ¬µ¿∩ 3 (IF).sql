function Get_High_Values (p_high_value in varchar2,
                          p_table_name in varchar2)
         return t_hvs
is
  l_hvs t_hvs default t_hvs();
  v_sql varchar2(4000);
  l_tokens t_varchar_table;
begin
  l_tokens := Get_Tokens(p_string => p_high_value);
  for c_ch in (select tc.TABLE_NAME, pc.column_name, pc.column_position, tc.DATA_TYPE, 
                      max(pc.column_position) over (partition by tc.TABLE_NAME) max_pos
                 from user_part_key_columns pc, user_tab_columns tc
                where pc.name = tc.TABLE_NAME and pc.column_name = tc.COLUMN_NAME and pc.object_type = 'TABLE'
                  and tc.table_name = p_table_name
                order by tc.TABLE_NAME, pc.column_position)
  loop
    l_hvs.extend;
    v_sql := 'select '||l_tokens(c_ch.column_position)||' into :a from dual';
    if c_ch.data_type = 'DATE' then
      if l_tokens(c_ch.column_position) = 'MAXVALUE' then
        l_hvs(l_hvs.last).d_date := p_consts.cINFINITY_DATE;
      else
        execute immediate v_sql into l_hvs(l_hvs.last).d_date;
      end if;
    elsif c_ch.data_type like 'TIMESTAMP%' then
      if  c_ch.data_type like 'TIMESTAMP%TIME ZONE' then
        if l_tokens(c_ch.column_position) = 'MAXVALUE' then
          l_hvs(l_hvs.last).t_timestamp_tz := p_consts.cINFINITY_DATE;
        else
          execute immediate v_sql into l_hvs(l_hvs.last).t_timestamp_tz;
        end if;
      else
        if l_tokens(c_ch.column_position) = 'MAXVALUE' then
          l_hvs(l_hvs.last).t_timestamp := p_consts.cINFINITY_DATE;
        else
          execute immediate v_sql into l_hvs(l_hvs.last).t_timestamp;
        end if;
      end if;
    elsif c_ch.data_type = 'NUMBER' then
      if l_tokens(c_ch.column_position) = 'MAXVALUE' then
        l_hvs(l_hvs.last).n_number := p_consts.cMaxN;
      else
        execute immediate v_sql into l_hvs(l_hvs.last).n_number;
      end if;
    elsif c_ch.data_type = 'VARCHAR2' then
      execute immediate v_sql into l_hvs(l_hvs.last).v_varchar;
    end if;
  end loop;
  return l_hvs;
end;

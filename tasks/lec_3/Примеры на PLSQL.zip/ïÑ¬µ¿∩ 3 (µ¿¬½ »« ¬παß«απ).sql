/*=================== ����� ��������� ====================*/

    for i in (select fsi.*, fi.v_value
                from fw_service_identifiers fsi, fw_identifiers fi
               where fsi.id_service_identifier_inst in
                     (select column_value
                        from table(t_idents))
                 and fsi.dt_start <= l_dt_plan
                 and fsi.dt_stop > l_dt_plan
                 and fsi.b_deleted = 0
                 and fi.id_identifier = fsi.id_identifier
                 and fi.b_deleted = 0) loop
      pack_capacity.saveIdentifier(pID_service_identifier_inst => i.id_service_identifier_inst,
                                   pID_SERVICE_INST => null,
                                   pID_SERVICE_IDENTIFIER => i.id_service_identifier,
                                   pID_IDENTIFIER => i.id_identifier,
                                   pV_VALUE => i.v_value, pV_Status => 'A',
                                   pID_identifier_group => i.id_identifier_group,
                                   pID_identifier_class => i.id_identifier_class,
                                   pDT_EVENT => l_dt_plan,
                                   pID_MASTER_TYPE => i.id_master_type,
                                   pID_MASTER_INST => i.id_master_inst,
                                   pB_BASE => i.b_base,
                                   pID_MANAGER => p_base_flow_exchange.loadFlowParamInteger(pId_flow => l_id_flow,
                                                                                             pV_param_name => 'ID_MANAGER'),
                                   pAction => P_CONSTS.FLEXY_ACTION_EDIT);
    end loop;

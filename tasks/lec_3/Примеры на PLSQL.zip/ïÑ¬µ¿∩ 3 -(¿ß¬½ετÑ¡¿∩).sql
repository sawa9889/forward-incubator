create or replace    function getLogin(pID_SERVICE    in number,
                    pID_SERVICE_IDENTIFIER   in number,
                    pID_TELNUM               in NUMBER,
                    pDT_EVENT      pack_sdk.TMST0) return varchar2 IS
                    
l_login VARCHAR2(255);      
v_num VARCHAR2(255);
pv_domain VARCHAR2(255);
id_ser NUMBER;
              
  BEGIN
    
    --RAISE_APPLICATION_ERROR(-20001, '���� �����');
    
    SELECT fi.v_pass, fi.v_value, fsi.id_service_inst  INTO l_login, v_num, id_ser
      FROM fw_service_identifiers fsi JOIN fw_identifiers fi ON fi.id_identifier = fsi.id_identifier
    WHERE fsi.id_service_identifier_inst = pID_TELNUM AND fsi.dt_start <= pDT_EVENT AND fsi.dt_stop > pDT_EVENT and fsi.b_deleted = 0;
    
    IF id_ser IS NULL THEN
      
      BEGIN
      
      IF SUBSTR(v_num, 1, 5) IN ('73652', '73654') THEN
        SELECT kd.v_domain INTO pv_domain
          FROM krm_domain kd WHERE kd.v_prefix = SUBSTR(v_num, 1, 5);
      ELSE 
        SELECT kd.v_domain INTO pv_domain
          FROM krm_domain kd WHERE kd.v_prefix = SUBSTR(v_num, 1, 6);       
      END IF; 
      
      EXCEPTION 
        WHEN OTHERS THEN 
        RAISE_APPLICATION_ERROR(-20001, '����� ��� �������� '||v_num||' �� ������');
      END;
      
    l_login := 's'||v_num||'@'||pv_domain;  
      
    END IF;
      
    return l_login;
  end;

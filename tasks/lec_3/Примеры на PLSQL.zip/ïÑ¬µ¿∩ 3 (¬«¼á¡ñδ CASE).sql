PROCEDURE saveServiceType(pID_REC       IN KRM_REPORT_SERVICE_TYPE.ID_REC%TYPE,
                          pv_name       IN fw_service.v_name%TYPE,
                          ptype_service IN KRM_REPORT_SERVICE_TYPE.type_service%TYPE,
                          pACTION       IN NUMBER) IS
  pid_service NUMBER;
BEGIN
  SELECT fs.id_service
    INTO pid_service
    FROM fw_service fs
   WHERE fs.v_name = pv_name;

  CASE
    WHEN pACTION = P_CONSTS.FLEXY_ACTION_DELETE THEN
      DELETE FROM KRM_REPORT_SERVICE_TYPE WHERE pID_REC = ID_REC;
    WHEN pACTION = P_CONSTS.FLEXY_ACTION_CREATE THEN
      INSERT INTO KRM_REPORT_SERVICE_TYPE
        (ID_REC, id_service, type_service)
      VALUES
        (S_KRM_SERVICE_TYPE.Nextval, pid_service, ptype_service);
    WHEN pACTION = P_CONSTS.FLEXY_ACTION_EDIT THEN
      UPDATE KRM_REPORT_SERVICE_TYPE
         SET id_service = pid_service, type_service = ptype_service
       WHERE ID_REC = pID_REC;
  END CASE;
EXCEPTION
	WHEN no_data_found THEN
   raise_application_error (p_consts.FLEXY_VALIDATION_ERROR,'����������� ������!');
  WHEN OTHERS THEN
    raise_application_error(p_consts.FLEXY_VALIDATION_ERROR,
                            '������ ������ ��� �������� � ����������');
END;
